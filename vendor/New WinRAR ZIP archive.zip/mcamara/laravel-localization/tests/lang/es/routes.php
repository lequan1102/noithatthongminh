<?php

return [
    'about'               => 'acerca',
    'view'                => 'ver/{id}',
    'view_project'        => 'ver/{id}/proyecto/{project_id?}',
    'manage'              => 'administrar/{file_id?}',
    'hello'               => 'Hola mundo',
    'test_text'           => 'Texto de prueba',
];
